#include "rtos.h"

__attribute__((weak)) void Init_Scheduler(void) {
    for (int i = 0; i < MAX_NUM_OF_TASKS; i++) {
        Task_List[i].id = 0;
        Task_List[i].Stack_Pointer = NULL;
        Task_List[i].priority = 0;
        Task_List[i].nextPt = NULL;
        memset(Task_List[i].TCB_Stack, 0, sizeof(Task_List[i].TCB_Stack));
    }
    CurrentTCB = NULL;
    current_index = 0;
    g_tick = 0;
}
