#include "rtos.h"

// returns 0 if successful, 1 if count > 24-bit
__attribute__((weak)) uint32_t Configure_Systick(uint32_t micro_seconds)
{
    // Calculate reload value for given microseconds
    uint32_t reload = (125 * micro_seconds) - 1;

    // SysTick is 24-bit, so maximum value is 0xFFFFFF
    if (reload > 0xFFFFFF)
        return 1; // Error: out of range

    // Disable SysTick before configuring
    systick_hw->csr = 0;

    // Set reload value
    systick_hw->rvr = reload;

    // Clear current value
    systick_hw->cvr = 0;

    // Enable SysTick: use processor clock, enable interrupt, enable counter
    systick_hw->csr = 
        (1 << 2) | // CLKSOURCE = processor clock (bit 2)
        (1 << 1) | // TICKINT = enable interrupt (bit 1)
        (1 << 0);  // ENABLE = counter enable (bit 0)

    return 0; // Success
}
