#include "rtos.h"

__attribute__((weak)) void Scheduler(void) {
    static uint32_t last_tick = 0;

    if ((g_tick - last_tick) >= quantum_ticks) {
        last_tick = g_tick;

        int attempts = 0;

        // Search for next valid task
        do {
            current_index = (current_index + 1) % MAX_TASKS;
            attempts++;
        } while (Task_List[current_index].id == 0 && attempts < MAX_TASKS);

        if (Task_List[current_index].id != 0) {
            CurrentTCB = &Task_List[current_index];
            if (CurrentTCB->start) {
                CurrentTCB->start();  // Call the task's function
            }
        }
    }
}
