#include "rtos.h"

__attribute__((weak)) int Remove_Task(uint32_t Task_ID) {

}
