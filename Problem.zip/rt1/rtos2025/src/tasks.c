#include "rtos.h"

// Simple delay loop for timing (since we're not using timers here)
void task_delay(volatile int count) {
    for (volatile int i = 0; i < count * 1000; i++);
}

// Task2: Count from 00 to 99 on display 0 and 1
void Task2(void) {
    while (1) {
        for (int i = 0; i < 100; i++) {
            display_buffer[0] = i % 10;       // Units on display 0
            display_buffer[1] = (i / 10) % 10; // Tens on display 1
            task_delay(500);
        }
    }
}

// Task3: Flash DP on display 3 at 1Hz
void Task3(void) {
    while (1) {
        display_buffer[3] |= 0x80; // Set DP bit
        task_delay(500);
        display_buffer[3] &= 0x7F; // Clear DP bit
        task_delay(500);
    }
}

// Task4: Hex down from F to 0 on display 4, then up 0 to F on display 5
void Task4(void) {
    while (1) {
        for (int i = 0xF; i >= 0; i--) {
            display_buffer[4] = i;
            task_delay(500);
        }
        for (int i = 0; i <= 0xF; i++) {
            display_buffer[5] = i;
            task_delay(500);
        }
    }
}

// Task5: Turn on segments one by one, then off in reverse, on display 7
void Task5(void) {
    const unsigned char segment_order[] = {
        0x01, // A
        0x02, // B
        0x04, // C
        0x08, // D
        0x10, // E
        0x20, // F
        0x40, // G
        0x80  // DP
    };

    while (1) {
        unsigned char pattern = 0x00;
        for (int i = 0; i < 8; i++) {
            pattern |= segment_order[i];
            display_buffer[7] = pattern;
            task_delay(300);
        }
        for (int i = 7; i >= 0; i--) {
            pattern &= ~segment_order[i];
            display_buffer[7] = pattern;
            task_delay(300);
        }
    }
}

// Task6: CLI interface for Load/Remove/PS
void Task6(void) {
    char cmd[10];
    while (1) {
        printf("\n> ");
        scanf("%s", cmd);

        if (strcmp(cmd, "PS") == 0) {
            printf("Task List:\n");
            for (int i = 0; i < MAX_NUM_OF_TASKS; i++) {
                if (Task_List[i].id != 0) {
                    printf("Task ID: %lu, Priority: %lu\n", Task_List[i].id, Task_List[i].priority);
                }
            }
        } else if (strncmp(cmd, "LD", 2) == 0) {
            int task_num = cmd[2] - '0';
            switch (task_num) {
                case 2: Load_Task(&Task2, 2, 0); break;
                case 3: Load_Task(&Task3, 3, 0); break;
                case 4: Load_Task(&Task4, 4, 0); break;
                case 5: Load_Task(&Task5, 5, 0); break;
                default: printf("Unknown task number\n"); break;
            }
        } else if (strncmp(cmd, "RM", 2) == 0) {
            int task_num = cmd[2] - '0';
            if (Remove_Task(task_num) == 0)
                printf("Removed Task %d\n", task_num);
            else
                printf("Failed to remove Task %d\n", task_num);
        } else {
            printf("Unknown command\n");
        }
    }
}
