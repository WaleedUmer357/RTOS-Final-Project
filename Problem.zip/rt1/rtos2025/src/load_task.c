
#include "rtos.h"
#include "pico/stdlib.h"


#include "hardware/irq.h"  // for irq_set_enabled()
#include "hardware/sync.h"


__attribute__((weak)) int Load_Task(void (*Task)(void), uint32_t Task_ID, uint32_t Task_Priority) {
    // Disable interrupts
    uint32_t irq_state = save_and_disable_interrupts();

    for (int i = 0; i < MAX_NUM_OF_TASKS; i++) {
        if (Task_List[i].id == 0) {
            // Found an empty slot

            TCB_t *tcb = &Task_List[i];

            // Clear TCB contents
            memset(tcb, 0, sizeof(TCB_t));

            // Set ID and priority
            tcb->id = Task_ID;
            tcb->priority = Task_Priority;

            // Initialise stack
            uint32_t *stack_top = &(tcb->TCB_Stack[STACK_SIZE - 1]);

            // Simulated exception frame (xPSR, PC, LR, R12, R3, R2, R1, R0)
            *(--stack_top) = 0x01000000;            // xPSR (Thumb bit set)
            *(--stack_top) = (uint32_t)Task;        // PC (task entry point)
            *(--stack_top) = 0xFFFFFFFD;            // LR (Return to thread with PSP)
            *(--stack_top) = 0x12121212;            // R12 (dummy)
            *(--stack_top) = 0x03030303;            // R3
            *(--stack_top) = 0x02020202;            // R2
            *(--stack_top) = 0x01010101;            // R1
            *(--stack_top) = 0x00000000;            // R0

            // Software-saved registers R4–R11
            *(--stack_top) = 0x11111111;            // R11
            *(--stack_top) = 0x10101010;            // R10
            *(--stack_top) = 0x09090909;            // R9
            *(--stack_top) = 0x08080808;            // R8
            *(--stack_top) = 0x07070707;            // R7
            *(--stack_top) = 0x06060606;            // R6
            *(--stack_top) = 0x05050505;            // R5
            *(--stack_top) = 0x04040404;            // R4

            // Set stack pointer
            tcb->Stack_Pointer = stack_top;

            // Restore interrupts
            restore_interrupts(irq_state);

            return Task_ID;
        }
    }

    // Restore interrupts if no slot was found
    restore_interrupts(irq_state);
    return -1;
}

// Prep 1
//     Task_List[0].TCB_Stack[STACK_SIZE - 1] = 0x01000000; // PSR
//     Task_List[0].Stack_Pointer = &Task_List[0].TCB_Stack[STACK_SIZE - 17]; // SP just below R8
//     printf("PSR value in Task_List[0]: 0x%08X\n", Task_List[0].TCB_Stack[STACK_SIZE - 1]);
// printf("Stack Pointer points to index: %ld\n", Task_List[0].Stack_Pointer - Task_List[0].TCB_Stack);
