// dht11.h
#ifndef DHT11_H
#define DHT11_H
#include <stdint.h>
#include <stdbool.h>

typedef struct {
  uint8_t humidity_int;
  uint8_t humidity_dec;
  uint8_t temp_int;
  uint8_t temp_dec;
  bool valid;
} DHT11_Data;

extern void DHT11_Init(void);                 // PB4 input with pull-up
extern bool DHT11_Read(DHT11_Data* out);      // blocks ~4 ms, call <= 1 Hz

#endif
