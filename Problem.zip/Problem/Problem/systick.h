// systick.h
#ifndef SYSTICK_H
#define SYSTICK_H
#include <stdint.h>

extern void Systick_Init(uint32_t sysclk_hz);
extern uint32_t Systick_Millis(void);
extern void SysTick_Handler(void);
#endif
