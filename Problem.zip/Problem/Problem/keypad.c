// keypad.c
#include "TM4C129.h"
#include <stdint.h>
#include <stdbool.h>
#include "keypad.h"

#define ROW GPIOD_AHB //input
#define COL GPIOK //output
#define PD (1<<3)  
#define PK (1<<9)  
#define ROW_MASK ((1<<0)|(1<<1)|(1<<2)|(1<<3))
#define COL_MASK ((1<<0)|(1<<1)|(1<<2))

static const char keymap[4][3] = {
  {'1','2','3'},
  {'4','5','6'},
  {'7','8','9'},
  {'*','0','#'}
};

static volatile char g_event = 0;
static uint8_t col = 0;
static uint8_t last_rows = 0, stable_rows = 0;
static uint8_t debounce = 0;

static inline uint8_t rows_active_low(void){
  uint32_t v = ROW->DATA & ROW_MASK;
  return (uint8_t)((~v) & ROW_MASK) & 0x0F;
}

void Keypad_Init(void){
  SYSCTL->RCGCGPIO |= (PD|PK);
  while(((SYSCTL->PRGPIO) & (PD|PK)) == 0){};
	

  ROW->DIR &= ~ROW_MASK;
  ROW->DEN |=  ROW_MASK;
  ROW->PUR |=  ROW_MASK;
  ROW->AFSEL &= ~ROW_MASK;
  ROW->AMSEL &= ~ROW_MASK;

  COL->DIR |=  COL_MASK;
  COL->DEN |=  COL_MASK;
  COL->AFSEL &= ~COL_MASK;
  COL->AMSEL &= ~COL_MASK;
  COL->DATA = (COL->DATA & ~COL_MASK) | COL_MASK;
}

void Keypad_ScanTick(void){
  // All columns high, then pull current column low
  COL->DATA = (COL->DATA & ~COL_MASK) | COL_MASK;
  COL->DATA &= ~(1<<col);

  uint8_t rows = rows_active_low();
	
  if(rows == last_rows){
    if(debounce < 4) debounce++;
    if(debounce == 4) stable_rows = rows;
  }else{
    debounce = 0;
  }
  last_rows = rows;

  static uint8_t prev=0;
  if(stable_rows && !prev){
    for(int r=0;r<4;r++){
      if(stable_rows & (1<<r)){
        g_event = keymap[r][col];
        break;
      }
    }
  }
  prev = stable_rows;

  col++; if(col>=3) col=0;
}

char Keypad_GetKeyEvent(void){
  char k = g_event; g_event=0; return k;
}
