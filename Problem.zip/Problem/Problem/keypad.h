#ifndef KEYPAD_H
#define KEYPAD_H

#include <stdint.h>

extern void Keypad_Init(void);
extern char Keypad_GetKeyEvent(void);

#endif
