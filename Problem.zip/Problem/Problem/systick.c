// systick.c
#include "TM4C129.h"
#include "systick.h"
#include "keypad.h"

static volatile uint32_t g_ms = 0;

void Systick_Init(uint32_t sysclk_hz){
  SysTick->CTRL = 0;
  SysTick->LOAD = (sysclk_hz/1000) - 1;
  SysTick->VAL  = 0;
  SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk;
}

uint32_t Systick_Millis(void){ return g_ms; }

void SysTick_Handler(void){
	g_ms++; 
}
