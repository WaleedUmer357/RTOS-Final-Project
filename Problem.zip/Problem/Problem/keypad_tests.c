#include "ES.h"
#include "systick.h"
#include "keypad.h"

int main(void)
{
    ES_setSystemClk(16);
    ES_Serial(0,"115200,8,N,1");
    Systick_Init(ES_getSystemClk());

    Keypad_Init();
    ES_Uprintf(0,"Interrupt-driven keypad test starting...\n");

    while(1)
    {
        char k = Keypad_GetKeyEvent();
        if(k){
            ES_Uprintf(0,"Key: %c\n", k);
        }
    }
}
