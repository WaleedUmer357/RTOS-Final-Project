#include "ES.h"
#include "dht11.h"

#if defined(TEST_DHT)
int main(void){
    ES_setSystemClk(16);
    ES_Serial(0, "115200,8,N,1");
    ES_Uprintf(0, "dht11_tests starting...\n");

    DHT11_Init();
    while(1){
        DHT11_Data d = {0};
        int rv = DHT11_Read(&d);
        if(rv==1 && d.valid){
            ES_Uprintf(0, "Temp=%uC Hum=%u%%\n", d.temp_dec, d.humidity_dec);
        }else{
            ES_Uprintf(0, "DHT11 read error (rv=%d, valid=%u)\n", rv, d.valid);
        }
        ES_msDelay(1000);
    }
}
#endif
