// dht11.c
#include "TM4C129.h"
#include "ES.h"
#include "dht11.h"

#define DHT_PORT GPIOB_AHB
#define DHT_BIT (1<<4) //PB4

static inline void to_output(void){
  DHT_PORT->DIR |= DHT_BIT;
  DHT_PORT->DEN |= DHT_BIT;
  DHT_PORT->AFSEL &= ~DHT_BIT;
  DHT_PORT->AMSEL &= ~DHT_BIT;
}

static inline void to_input_pullup(void){
  DHT_PORT->DIR &= ~DHT_BIT;
  DHT_PORT->DEN |= DHT_BIT;
  DHT_PORT->PUR |= DHT_BIT;
  DHT_PORT->AFSEL &= ~DHT_BIT;
  DHT_PORT->AMSEL &= ~DHT_BIT;
}

static bool wait_level(bool high, uint32_t timeout_us){
  while(timeout_us--){
    uint32_t v = (DHT_PORT->DATA & DHT_BIT)?1:0;
    if(v == (high?1:0)) return true;
    ES_usDelay(1);
  }
  return false;
}

void DHT11_Init(void){
  SYSCTL->RCGCGPIO |= (1<<1); // B
  while((SYSCTL->PRGPIO & (1<<1))==0){};
  to_input_pullup();
}

bool DHT11_Read(DHT11_Data* out){
  if(!out) return false;

  // Start: pull low >= 18 ms
  to_output();
  DHT_PORT->DATA &= ~DHT_BIT;
  ES_msDelay(20);
  to_input_pullup();
  ES_usDelay(30);

  // Response: low 80us, high 80us
  if(!wait_level(false, 300)) { out->valid=false; return false; }
  ES_usDelay(80);
  if(!wait_level(true, 300))  { out->valid=false; return false; }
  ES_usDelay(80);

  uint8_t data[5] = {0};
  for(int i=0;i<40;i++){
    // 50us low
    if(!wait_level(false, 300)) { out->valid=false; return false; }
    ES_usDelay(50);
    // measure high width by sampling at ~40us
    if(!wait_level(true, 300))  { out->valid=false; return false; }
    ES_usDelay(40);
    uint32_t high_now = (DHT_PORT->DATA & DHT_BIT)?1:0;
    data[i/8] <<= 1;
    if(high_now) data[i/8] |= 1;
    // wait for line to drop before next bit
    if(!wait_level(false, 300)) { out->valid=false; return false; }
  }

  uint8_t sum = (uint8_t)(data[0]+data[1]+data[2]+data[3]);
  bool ok = (sum == data[4]);

  out->humidity_int = data[0];
  out->humidity_dec = data[1];
  out->temp_int     = data[2];
  out->temp_dec     = data[3];
  out->valid        = ok;
  return ok;
}
